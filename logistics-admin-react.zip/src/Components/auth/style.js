import { Tabs, styled, Tab } from "@mui/material";


// export const FormTabs = styled(Tabs)(({ theme }) => ({
//     // fontWeight: 700
// }));

export const FormTab = styled(Tab)(({ theme }) => ({
    fontWeight: 700
})); 