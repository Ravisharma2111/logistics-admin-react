import React from "react";
import AdminLayout from "../layout";

const HomePage = () => {
  return <AdminLayout />;
};

export default HomePage;
